# DepthWizard & 3D Fly Through — Backend

College project backend built with:

- Python
- FastAPI
- SQLite
- SQLAlchemy
- JWT authentication
- Pillow
- OpenCV
- NumPy

## Features

1. User registration
2. User login with JWT
3. Protected APIs
4. Image upload
5. Image validation
6. User image history
7. Depth-map generation
8. Depth-based fly-through video
9. Result history
10. Result deletion
11. Swagger API documentation

## 1. Open the project

Open this `backend` folder in VS Code.

## 2. Create virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

Linux/macOS:

```bash
python3 -m venv venv
source venv/bin/activate
```

## 3. Install packages

```bash
pip install -r requirements.txt
```

## 4. Run

```bash
uvicorn main:app --reload
```

## 5. Open Swagger

http://127.0.0.1:8000/docs

## API flow

### Register

POST `/auth/register`

```json
{
  "name": "Student",
  "email": "student@example.com",
  "password": "Password123"
}
```

### Login

POST `/auth/login`

```json
{
  "email": "student@example.com",
  "password": "Password123"
}
```

Copy the returned access token.

In Swagger click `Authorize` and enter:

```text
Bearer YOUR_TOKEN
```

### Upload

POST `/images/upload`

Choose a JPG/PNG image.

### Generate

POST `/results/generate/{image_id}`

Example:

```text
POST /results/generate/1
```

### History

GET `/results`

### One result

GET `/results/{result_id}`

### Delete

DELETE `/results/{result_id}`

## Output folders

Uploaded images:

```text
uploads/
```

Generated depth maps and videos:

```text
results/
```

Database:

```text
depthwizard.db
```

## Important project note

The included depth estimator is a lightweight baseline that converts image luminance into a normalized depth map. It is designed to make the complete backend runnable on a normal college laptop.

For the final AI version, replace:

```text
services/depth_estimation.py
```

with a pretrained monocular depth-estimation model such as Depth Anything or MiDaS. The rest of the backend can remain unchanged.

## Project explanation

The backend follows this flow:

User → Authentication → Image Upload → Validation → Depth Map → Fly-through → Results History

This architecture keeps authentication, database operations, image processing and AI processing separated into modules.
