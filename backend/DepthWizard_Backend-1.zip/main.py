from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from database import engine, Base
from routers import auth_routes, image_routes, result_routes

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="DepthWizard & 3D Fly Through API",
    description="College project backend for authentication, image validation, depth maps, 3D fly-through and result history.",
    version="1.0.0",
)

app.include_router(auth_routes.router)
app.include_router(image_routes.router)
app.include_router(result_routes.router)

# Serve generated files during local development.
app.mount("/files", StaticFiles(directory="."), name="files")


@app.get("/")
def root():
    return {
        "project": "DepthWizard & 3D Fly Through",
        "status": "running",
        "version": "1.0.0",
        "docs": "/docs",
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
